package br.com.banksecure.app.service;

import br.com.banksecure.app.domain.Cliente;
import br.com.banksecure.app.dto.request.ClienteRequest;
import br.com.banksecure.app.dto.response.ClienteResponse;
import br.com.banksecure.app.exception.CpfExistenteException;
import br.com.banksecure.app.exception.IdadeInvalidaException;
import br.com.banksecure.app.mapper.ClienteMapper;
import br.com.banksecure.app.repository.ClienteRepository;
import br.com.banksecure.app.util.ValidarAcesso;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.Period;
import java.util.List;

import static br.com.banksecure.app.enums.ErrorMessage.*;

@Service
public class ClienteService {

    private final ClienteRepository repository;
    private final ValidarAcesso acesso;
    private final ClienteMapper mapper;

    public ClienteService(ClienteRepository repository, ValidarAcesso acesso, ClienteMapper mapper) {
        this.repository = repository;
        this.acesso = acesso;
        this.mapper = mapper;
    }


    @Transactional
    public ClienteResponse cadastrar(ClienteRequest request, Long funcionarioId) {
        acesso.validarAcesso(funcionarioId);

        if (repository.existsByCpf(request.cpf())) {
            throw new CpfExistenteException(CPF_JA_EXISTE.getMessage());
        }

        Cliente cliente = mapper.converterParaEntity(request);

        validarMaioridade(cliente.getDataNascimento());

        repository.save(cliente);

        return mapper.converterParaResponse(cliente);
    }


    private void validarMaioridade(LocalDate dataNascimento) {

        int idade = Period.between(dataNascimento, LocalDate.now()).getYears();

        if (idade < 18) {
            throw new IdadeInvalidaException(MENOR_IDADE.getMessage());
        }

        final int idadeMax = 120; if (idade > idadeMax) {
            throw new IdadeInvalidaException(MAIOR_QUE_120.getMessage());
        }
    }

    public List<ClienteResponse> listarTodosClientes(Long funcionarioId) {
        acesso.validarAcesso(funcionarioId);

        List<Cliente> clientes = repository.findAll();
        return clientes.stream()
                .map(mapper::converterParaResponse)
                .toList();
    }
}
