package br.com.banksecure.app.dto.request;

import br.com.banksecure.app.enums.TipoSeguroeBem;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Builder;

import java.math.BigDecimal;

@Builder
public record SeguroRequest(
        @NotBlank(message = "O título do seguro é obrigatório.")
        String titulo,

        String coberturaMinima,

        @NotNull(message = "O valor do prêmio base é obrigatório.")
        @Positive(message = "O valor do prêmio base deve ser maior que zero.")
        BigDecimal valorPremioBase,

        @NotNull(message = "O tipo de seguro é obrigatório.")
        TipoSeguroeBem tipo
) {
}
